from pkg_resources import require
from odoo import api, fields, models, tools, _
from datetime import date,datetime

class PumpReading(models.Model):
    _name = "pump.reading"
    _description = "Pump Reading"
    _order = "id desc"
    
    pump_id = fields.Many2one("station.pump", string="Pump")
    date = fields.Date(string="Date",)
    p_opening_reading = fields.Float(string="Opening Reading")
    p_closing_reading = fields.Float(string="Closing Reading")
    user_id = fields.Many2one("res.users", string="User")
    shift_id = fields.Many2one("pump.shift", string="Shift")
    p_expected_sales = fields.Float(string="Expected Sales",
                                    compute="_compute_pump_reading_sales",
                                    store = True)
    is_readonly = fields.Boolean(compute="_compute_pump_field_readonly")

    @api.model
    def create(self,vals):
        res = super(PumpReading,self).create(vals)
        latest_record = self.search([('pump_id','=',res.pump_id.id),('id','!=',res.id)],order = "id desc",limit = 1)
        res.p_opening_reading = latest_record.p_closing_reading 
        return res
        
    def _compute_pump_reading_sales(self):
        for record in self:
            record.p_expected_sales = 0.0
            total_sale = 0.0
            if record.p_closing_reading:
                total_sale = record.p_closing_reading - record.p_opening_reading
                record.p_expected_sales = total_sale
                
    def _compute_pump_field_readonly(self):
        for rec in self:
            rec.is_readonly = False
            abc = rec.env.user.has_group("mb_pump_station.group_edit_reading_manager")
            date = fields.Date.today()
            if not rec.env.user.has_group("mb_pump_station.group_edit_reading_manager") and rec.date < date:
                rec.is_readonly = True

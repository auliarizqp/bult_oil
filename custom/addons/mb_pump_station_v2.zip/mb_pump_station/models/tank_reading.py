from odoo import api, fields, models, tools, _

class TankReading(models.Model):
    _name = "tank.reading"
    _description = "Tank Reading"
    _order = "id desc"
    
    tank_id = fields.Many2one("pump.tank", string="Tank")
    date = fields.Date(string="Date")
    t_opening_reading = fields.Float(string="Opening Reading")
    t_closing_reading = fields.Float(string="Closing Reading")
    user_id = fields.Many2one("res.users", string="User")
    shift_id = fields.Many2one("pump.shift", string="Shift")
    purchase = fields.Float(string="Purchase")
    t_expected_sales = fields.Float(string="Expected Sales",
                                    compute="_compute_tank_reading_sales",
                                    store=True)
    t_is_readonly = fields.Boolean(compute="_compute_tank_field_readonly")
    @api.model
    def create(self,vals):
        res = super(TankReading,self).create(vals)
        latest_record = self.search([('tank_id','=',res.tank_id.id),('id','!=',res.id)],order = "id desc",limit = 1)
        res.t_opening_reading = latest_record.t_closing_reading
        return res
        
    def _compute_tank_reading_sales(self):
        for record in self:
            record.t_expected_sales = 0.0
            total_sale = 0.0
            if record.t_closing_reading:
                total_sale = record.t_closing_reading - record.t_opening_reading
                record.t_expected_sales = total_sale
                
    def _compute_tank_field_readonly(self):
        for rec in self:
            rec.t_is_readonly = False
            abc = rec.env.user.has_group("mb_pump_station.group_edit_reading_manager")
            date = fields.Date.today()
            if not rec.env.user.has_group("mb_pump_station.group_edit_reading_manager") and rec.date < date:
                rec.t_is_readonly = True

# See LICENSE file for full copyright and licensing details.

from . import account_move
from . import hotel_folio
from . import hotel_room
from . import hotel_services
from . import product_product
from . import res_company
